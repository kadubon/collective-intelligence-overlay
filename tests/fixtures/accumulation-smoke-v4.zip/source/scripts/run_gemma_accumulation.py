"""Finite longitudinal Gemma study over the source-only registered application.

Smoke, sensitivity calibration and confirmation have separate immutable outputs.
Confirmation refuses unpushed preregistration or changed source/options/seeds.
"""

import argparse
import asyncio
import hashlib
import json
import subprocess
import time
from datetime import UTC, datetime
from pathlib import Path

from accumulation_application import DIGEST, MODEL
from accumulation_host import OwnedOllama, ProcessObserver
from accumulation_session import ROOT, StudySession
from accumulation_tasks import World

from collective_intelligence_overlay.adapters.inference_observer import write_new


def sources():
    paths = list((ROOT / "src").rglob("*.py"))
    paths += list((ROOT / "src").rglob("*.rego"))
    paths += list((ROOT / "scripts").glob("accumulation_*.py"))
    paths += [
        ROOT / p
        for p in (
            "scripts/run_gemma_accumulation.py",
            "scripts/verify_gemma_accumulation.py",
            "scripts/production_session.py",
            "scripts/run_production_experiment.py",
            "tests/e2e/production_mesh.py",
            "examples/evaluate_documents.py",
            "pyproject.toml",
            "uv.lock",
        )
    ]
    return {
        p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted(paths)
    }


def preregistration(args, protocol):
    if args.classification != "confirmation":
        return None
    if args.prereg_commit is None:
        raise ValueError("confirmation requires a committed and pushed preregistration")
    relative = args.protocol.resolve().relative_to(ROOT).as_posix()
    committed = subprocess.check_output(
        ["git", "show", args.prereg_commit + ":" + relative], cwd=ROOT
    )
    if committed != args.protocol.read_bytes():
        raise ValueError("preregistered original differs from current protocol")
    for tip in ("HEAD", "origin/main"):
        subprocess.run(
            ["git", "merge-base", "--is-ancestor", args.prereg_commit, tip], cwd=ROOT, check=True
        )
    remote = subprocess.check_output(
        ["git", "ls-remote", "origin", "refs/heads/main"], cwd=ROOT, text=True
    ).split()[0]
    subprocess.run(
        ["git", "merge-base", "--is-ancestor", args.prereg_commit, remote], cwd=ROOT, check=True
    )
    if protocol["classification"] != "confirmation" or protocol["model_digest"] != DIGEST:
        raise ValueError("explicit independent confirmation protocol required")
    if datetime.fromisoformat(protocol["registered_at"]) >= datetime.now(UTC):
        raise ValueError("preregistration must precede the first confirmation request")
    if protocol["sources"] != sources():
        raise ValueError("confirmation source/lock/factory/checker changed")
    return {
        "commit": args.prereg_commit,
        "protocol_sha256": hashlib.sha256(committed).hexdigest(),
        "remote_head_before_inference": remote,
    }


def smoke_protocol():
    return {
        "id": "cio-042-accumulation-smoke-v4",
        "classification": "smoke",
        "world_seeds": [982317],
        "arms": ["E"],
        "model": MODEL,
        "model_digest": DIGEST,
        "model_options": {
            "num_ctx": 8192,
            "num_predict": 1536,
            "temperature": 0.2,
            "top_p": 0.95,
            "top_k": 64,
            "draft_num_predict": 0,
        },
        "request_seconds": 240,
        "caps": {
            "model_calls": 2,
            "model_tokens": 19456,
            "application_actions": 1024,
            "wall_seconds": 900,
        },
        "cohort_wall_seconds": 1200,
        "schedule": "two-connection-and-usage-probes-not-performance",
        "sources": sources(),
    }


def forms(world, prefix):
    return [
        ("producer", world.sales(prefix + "-sql-low", "low")),
        ("receiver", world.calibration(prefix + "-calibration-middle", "middle")),
    ]


async def run(args):
    args.home, args.output = args.home.resolve(), args.output.resolve()
    protocol = json.loads(args.protocol.read_bytes()) if args.protocol else smoke_protocol()
    if protocol["classification"] != args.classification or protocol["model_digest"] != DIGEST:
        raise ValueError("protocol/cohort/model mismatch")
    registration = preregistration(args, protocol)
    if protocol["sources"] != sources():
        raise ValueError("declared source changed before model/server startup")
    args.output.mkdir()
    args.created = True
    args.home.mkdir()
    write_new(args.output / "protocol.json", protocol)
    write_new(args.output / "source-manifest.json", protocol["sources"])
    for name in protocol["sources"]:
        destination = args.output / "source" / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes((ROOT / name).read_bytes())
    observer = ProcessObserver(args.output / "os-processes.jsonl", protocol["cohort_wall_seconds"])
    server = OwnedOllama(
        args.home / "ollama",
        args.output,
        port=args.port,
        context=protocol["model_options"]["num_ctx"],
    )
    start = time.monotonic()
    cohorts = []
    observer.start()
    try:
        await server.start()
        async with asyncio.timeout(protocol["cohort_wall_seconds"]):
            for seed in protocol["world_seeds"]:
                world = World(seed)
                for arm in protocol["arms"]:
                    offers = forms(world, args.classification)
                    checks = {
                        f"smoke-{i}": [
                            {"problem": p.model_dump(mode="json"), "expected": world.expected(p)}
                        ]
                        for i, (_, p) in enumerate(offers)
                    }
                    model = {
                        "host": server.host,
                        "seconds": protocol["request_seconds"],
                        "options": protocol["model_options"],
                    }
                    output = args.output / (world.id + "-" + arm)
                    s = StudySession(
                        args.home / (world.id + "-" + arm),
                        output,
                        world,
                        arm,
                        protocol,
                        model,
                        checks,
                    )
                    result = {"world": world.id, "seed": seed, "arm": arm, "offers": []}
                    try:
                        await s.initialize()
                        for i, (peer, p) in enumerate(offers):
                            result["offers"].append(
                                await s.offer(peer, f"smoke-{i}", p, s.stock, attempts=1)
                            )
                    except Exception as error:
                        result["error_type"] = type(error).__name__
                    finally:
                        result["export"] = await s.finish()
                        write_new(output / "arm-result.json", result)
                        cohorts.append(result)
                    if sources() != protocol["sources"]:
                        raise ValueError("source changed during frozen inference")
        model_observations = [
            read_observation(p) for p in args.output.glob("world-*/model/*/observation.json")
        ]
        connected = len(model_observations) == 2 and all(
            o["status"] == 200 and o["stream_complete"] and o["tokens_measured"] is not None
            for o in model_observations
        )
        write_new(
            args.output / "cohort.json",
            {
                "classification": args.classification,
                "preregistration": registration,
                "arms": cohorts,
                "inclusive_wall_seconds": time.monotonic() - start,
                "smoke_excluded_from_performance": args.classification == "smoke",
                "smoke_connection_and_usage_passed": connected,
            },
        )
    finally:
        await server.close()
        observer.close()
    return 0 if connected and all(not c.get("error_type") for c in cohorts) else 1


def read_observation(path):
    return json.loads(path.read_bytes())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--classification", choices=("smoke",), required=True)
    parser.add_argument("--protocol", type=Path)
    parser.add_argument("--prereg-commit")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--home", type=Path, required=True)
    parser.add_argument("--port", type=int, default=11443)
    args = parser.parse_args()
    try:
        result = asyncio.run(run(args))
    except BaseException as error:
        if getattr(args, "created", False):
            write_new(
                args.output / "termination.json",
                {
                    "error_type": type(error).__name__,
                    "classification": args.classification,
                    "completed": False,
                    "at": datetime.now(UTC).isoformat(),
                },
            )
        raise
    raise SystemExit(result)


if __name__ == "__main__":
    main()
