"""Bounded goal observations and untrusted alternatives to installed operations.

These APIs add no execution lifecycle. Operator registration fixes contracts and
allowlists; qualification remains with Overlay and actuation with Registry/Executor.
"""

from __future__ import annotations

import asyncio
import json
import time
from collections import Counter
from datetime import timedelta
from decimal import Decimal
from typing import Any, Literal, Self

from jsonschema import ValidationError as SchemaError  # type: ignore[import-untyped]
from pydantic import BaseModel, ConfigDict, Field, JsonValue, TypeAdapter, model_validator
from securesystemslib.exceptions import FormatError, VerificationError

from .bindings import ExecutionContext, InvalidArguments, Registry, fingerprint
from .blocking import run_blocking
from .models import (
    BindingRef,
    Capability,
    Cost,
    Decision,
    Event,
    Identifier,
    Opportunity,
    Outcome,
    Proposal,
    RecordRef,
    UseRequest,
    WorkKind,
    WorkObservation,
    now,
    uid,
)
from .queries import RecordQuery
from .reobservation import ObservationLedger, Reobservation, ReobservationPolicy, cause_id
from .security import MAX_RECORD_BYTES, Identity, Principal, verify
from .storage import Conflict, Store, projection_digest

RejectionCategory = Literal[
    "format",
    "authentication",
    "authorization",
    "scope",
    "expired",
    "reference",
    "arguments",
    "conflict",
]


class ProposalRejected(ValueError):
    """Expected rejection of one untrusted alternative; never a storage failure."""

    def __init__(self, category: RejectionCategory, message: str) -> None:
        self.category = category
        super().__init__(message)


class ProposalRejection(BaseModel):
    """Bounded categorical owner observation, without peer text or raw arguments."""

    model_config = ConfigDict(extra="forbid", frozen=True)
    peer: Identifier
    category: RejectionCategory
    count: int = Field(ge=1, le=128)


def authenticate_proposal(envelope: Any, caller: str, principals: dict[str, Principal]) -> Proposal:
    """Convert errors only at the pure untrusted DSSE/type validation boundary."""
    if (
        not isinstance(envelope, dict)
        or not isinstance(envelope.get("payload"), str)
        or not isinstance(envelope.get("payloadType"), str)
        or not isinstance(envelope.get("signatures"), list)
        or any(
            not isinstance(s, dict)
            or not isinstance(s.get("keyid"), str)
            or not isinstance(s.get("sig"), str)
            for s in envelope["signatures"]
        )
    ):
        raise ProposalRejected("format", "invalid proposal envelope")
    try:
        size = len(json.dumps(envelope).encode())
    except (TypeError, ValueError, RecursionError) as exc:
        raise ProposalRejected("format", "invalid proposal JSON") from exc
    if size > MAX_RECORD_BYTES:
        raise ProposalRejected("format", "proposal envelope exceeds byte bound")
    try:
        record = verify(envelope, principals)
    except (ValueError, TypeError, KeyError, RecursionError, FormatError, VerificationError) as exc:
        raise ProposalRejected("authentication", "proposal authentication or type failed") from exc
    if not isinstance(record, Proposal):
        raise ProposalRejected("format", "expected a proposal")
    if record.issuer != caller:
        raise ProposalRejected("authentication", "proposal issuer must match authenticated peer")
    return record


def summarize_rejections(
    rejected: list[tuple[str, RejectionCategory]],
) -> tuple[ProposalRejection, ...]:
    return tuple(
        ProposalRejection(peer=peer, category=category, count=count)
        for (peer, category), count in sorted(Counter(rejected).items())
    )


def record_rejections(
    store: Store,
    identity: Identity,
    opportunity: Opportunity,
    rejected: tuple[ProposalRejection, ...],
) -> None:
    """At most one local event per peer/category, with no additional cost charge."""
    for rejection in rejected:
        event = Event(
            schema_version="3",
            issuer=identity.name,
            subject=opportunity.subject,
            action="recommendation",
            task_id=opportunity.id,
            attempt_id=uid(),
            correlation_id=opportunity.id,
            work=WorkObservation(
                receiver=identity.name,
                scope=opportunity.scope,
                policy_digest=opportunity.policy_digest,
                goal_id=opportunity.goal_id,
                goal_digest=opportunity.goal_digest,
                opportunity_id=opportunity.id,
                work_kind=opportunity.work_kind,
                stage="selection",
                result="rejected_" + rejection.category,
                # The enclosing collection/selection records the input count.
                # Categories must not double-count inspected proposals in metrics.
                proposals_received=0,
            ),
        )
        store.put(identity.sign(event))


class Goal(BaseModel):
    """Trusted host configuration, never accepted from a proposal or model output."""

    model_config = ConfigDict(extra="forbid", frozen=True)
    id: Identifier
    revision: Identifier
    request: UseRequest
    checker: BindingRef
    checker_arguments: dict[str, JsonValue] = Field(default_factory=dict, max_length=32)
    builders: tuple[BindingRef, ...] = Field(min_length=1, max_length=32)
    peers: tuple[Identifier, ...] = Field(default=(), max_length=16)
    lifetime_seconds: int = Field(default=900, ge=1, le=86400)

    @model_validator(mode="after")
    def fixed_target(self) -> Self:
        if self.request.purpose != "reuse" or not self.request.binding_digest:
            raise ValueError("goal requires an exact ordinary-use target binding")
        if not self.request.capability_issuer:
            raise ValueError("goal requires exact target issuer")
        if len({(b.issuer, b.id) for b in self.builders}) != len(self.builders):
            raise ValueError("duplicate installed builder alternative")
        return self

    @property
    def digest(self) -> str:
        return fingerprint(self.model_dump(mode="json"))

    @property
    def contract_digest(self) -> str:
        """Fixed host contract, excluding only candidate identity and goal revision."""
        return fingerprint(
            self.model_dump(
                mode="json",
                exclude={
                    "revision": True,
                    "request": {"binding_digest": True, "subject": {"version", "digest"}},
                },
            )
        )


class Discovery(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    opportunities: tuple[Opportunity, ...]
    discovered: int
    deduplicated: int
    satisfied: int
    next_goal: int | None
    expired: tuple[Opportunity, ...] = Field(default=(), max_length=32)
    superseded: tuple[Opportunity, ...] = Field(default=(), max_length=32)
    next_action: Literal["reobserve"] | None = None


class ProposalDraft(BaseModel):
    """Model-controlled builder input; no fields for grants, goals or checker changes."""

    model_config = ConfigDict(extra="forbid", frozen=True)
    builder: BindingRef
    arguments: dict[str, JsonValue] = Field(max_length=32)
    alternative: Identifier
    estimates: tuple[Cost, ...] = Field(default=(), max_length=8)


class ProposalDrafts(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    alternatives: tuple[ProposalDraft, ...] = Field(max_length=8)


def propose(
    opportunity: Opportunity, reference: RecordRef, identity: Identity, drafts: ProposalDrafts
) -> tuple[Proposal, ...]:
    """Deterministically wrap bounded alternatives; the receiver must validate each.

    Installed deterministic proposers and MAF structured output use this same path.
    Signing does not imply that a remote owner will accept or execute the result.
    """
    if (
        reference.kind != "opportunity"
        or reference.issuer != opportunity.issuer
        or reference.id != opportunity.id
    ):
        raise ValueError("proposal reference does not identify its opportunity")
    if identity.name not in opportunity.receivers or opportunity.expires_at <= now():
        raise ValueError("opportunity is not shared with this proposer or has expired")
    result = []
    for draft in drafts.alternatives:
        key = fingerprint(
            {
                "observation": reference.model_dump(mode="json"),
                "issuer": identity.name,
                "draft": draft.model_dump(mode="json"),
            }
        )
        result.append(
            Proposal(
                id="proposal-" + key,
                issuer=identity.name,
                subject=opportunity.subject,
                scope=opportunity.scope,
                receivers=(opportunity.issuer,),
                goal_id=opportunity.goal_id,
                goal_digest=opportunity.goal_digest,
                opportunity=reference,
                builder=draft.builder,
                arguments=draft.arguments,
                alternative=draft.alternative,
                estimates=draft.estimates,
                created_at=opportunity.created_at,
                expires_at=opportunity.expires_at,
            )
        )
    if len({item.id for item in result}) != len(result):
        raise ValueError("duplicate proposed alternative")
    return tuple(result)


def work_kind(reasons: tuple[str, ...]) -> WorkKind:
    """Operational routing only: these reasons never grant admission."""
    if {
        "known_revocation",
        "dependency_rejected",
        "in_scope_counterexample",
        "formation_input_requires_requalification",
    } & set(reasons):
        return "repair"
    if {"scope_mismatch", "dependency_requires_requalification"} & set(reasons):
        return "connection"
    if "freshness_unknown" in reasons:
        return "observation"
    if "independent_evidence_required" in reasons or "capability_expired" in reasons:
        return "verification"
    if "ambiguous_or_missing_subject" in reasons:
        return "formation"
    return "observation"


class Opportunities:
    def __init__(
        self,
        registry: Registry,
        identity: Identity,
        goals: tuple[Goal, ...],
        *,
        reobservation_policy: ReobservationPolicy | None = None,
    ) -> None:
        if identity.name != registry.overlay.store.owner:
            raise ValueError("opportunity identity must belong to the local owner")
        if not 1 <= len(goals) <= 32 or len({g.id for g in goals}) != len(goals):
            raise ValueError("register 1 to 32 distinct bounded goals")
        for goal in goals:
            if goal.request.receiver != identity.name:
                raise ValueError("goal admission belongs to the local receiver")
            if not set(goal.peers) <= registry.overlay.store.principals.keys():
                raise ValueError("goal contains an unconfigured peer")
        self.registry = registry
        self.identity = identity
        self._goals = {g.id: g.model_copy(deep=True) for g in goals}
        self._digests = {g.id: g.digest for g in goals}
        self.observations = ObservationLedger(registry.overlay.store, identity)
        self.reobservation_policy = reobservation_policy or ReobservationPolicy()

    def goal(self, goal_id: str) -> Goal:
        goal = self._goals.get(goal_id)
        if goal is None or goal.digest != self._digests[goal_id]:
            raise ValueError("unregistered or modified goal")
        return goal.model_copy(deep=True)

    def select_target(
        self,
        goal_id: str,
        expected_goal_digest: str,
        binding_id: str,
        candidate_reference: RecordRef,
    ) -> Goal:
        """Host-only candidate transition, preserving the registered contract.

        The application persists the returned goal alongside its installed artifact
        and restores it on startup. This changes no evidence or admission and is
        deliberately absent from the peer protocol and proposal schema.
        """
        goal = self.goal(goal_id)
        if goal.digest != expected_goal_digest:
            raise Conflict("goal changed before candidate selection")
        if candidate_reference.kind != "capability":
            raise ValueError("target requires an exact signed capability reference")
        candidate = self.registry.overlay.store.resolve_reference(candidate_reference)
        binding = self.registry.inspect(binding_id)
        if (
            not isinstance(candidate, Capability)
            or candidate.schema_version not in {"2", "3"}
            or candidate.issuer != goal.request.capability_issuer
            or candidate.issuer != binding.issuer
            or candidate.subject != binding.subject
            or candidate.subject.id != goal.request.subject.id
            or candidate.binding_digest != binding.digest
            or candidate.scope != goal.request.scope
            or binding.scope != goal.request.scope
        ):
            raise ValueError("candidate does not preserve the registered target contract")
        if (
            goal.request.subject == candidate.subject
            and goal.request.binding_digest == binding.digest
        ):
            return goal
        request = UseRequest.model_validate(
            {
                **goal.request.model_dump(),
                "subject": candidate.subject,
                "binding_digest": binding.digest,
            }
        )
        updated = Goal.model_validate(
            {
                **goal.model_dump(),
                "revision": fingerprint(
                    {"previous": goal.digest, "candidate": candidate_reference.model_dump()}
                ),
                "request": request,
            }
        )
        self._goals[goal_id] = updated.model_copy(deep=True)
        self._digests[goal_id] = updated.digest
        return updated.model_copy(deep=True)

    async def _observe(self, goal: Goal) -> Opportunity | None:
        """Always qualify current owner inputs; never extend an old signed basis."""
        decision = await self.registry.overlay.qualify(goal.request)
        if decision.outcome == Outcome.ACCEPT:
            return None
        observation = fingerprint(
            {
                "goal": goal.digest,
                "outcome": decision.outcome.value,
                "reasons": sorted(decision.reasons),
                "revisions": decision.revisions,
                "evidence_ids": sorted(decision.evidence_ids),
                "policy": decision.policy_digest,
            }
        )
        kind = work_kind(decision.reasons)
        if "missing_ambiguous_or_cyclic_dependency" in decision.reasons:
            target = await run_blocking(
                self.registry.overlay.store.record_page,
                RecordQuery(
                    kinds=("capability",),
                    issuer=goal.request.capability_issuer,
                    subject=goal.request.subject,
                ),
                limit=1,
            )
            if not target.items:
                kind = "formation"
        timestamp = now()
        return Opportunity(
            id="op-" + observation,
            issuer=self.identity.name,
            subject=goal.request.subject,
            scope=goal.request.scope,
            receivers=(self.identity.name, *goal.peers),
            goal_id=goal.id,
            goal_digest=goal.digest,
            goal_contract_digest=goal.contract_digest,
            work_kind=kind,
            basis=(
                RecordRef(
                    kind="decision",
                    issuer=self.identity.name,
                    id=decision.id,
                    payload_digest=projection_digest(decision.model_dump(mode="json")),
                ),
            ),
            observation_digest=observation,
            policy_digest=decision.policy_digest,
            reasons=decision.reasons,
            expected_contract=goal.request.scope.output_contract,
            checker=goal.checker,
            permissions=goal.request.scope.permissions,
            created_at=timestamp,
            expires_at=timestamp + timedelta(seconds=goal.lifetime_seconds),
        )

    async def reobserve(
        self,
        opportunity_id: str,
        request_id: str,
        reason: str,
        *,
        caller: str,
        new_attempt: bool = False,
    ) -> Reobservation:
        """Explicit owner observation command; old choices and executions remain immutable."""
        for value in (opportunity_id, request_id, reason, caller):
            TypeAdapter(Identifier).validate_python(value)
        TypeAdapter(bool).validate_python(new_attempt, strict=True)
        if caller != self.identity.name:
            raise ValueError("reobservation requires the local owner")
        command = fingerprint(
            {
                "opportunity": opportunity_id,
                "request": request_id,
                "reason": reason,
                "caller": caller,
                "new_attempt": new_attempt,
            }
        )
        replay = await run_blocking(self.observations.replay, request_id, command)
        if replay is not None:
            return replay
        store = self.registry.overlay.store
        reference = await run_blocking(store.reference, "opportunity", caller, opportunity_id)
        previous = await run_blocking(store.resolve_reference, reference)
        if not isinstance(previous, Opportunity) or previous.issuer != caller:
            raise ValueError("reobservation requires an exact local opportunity")
        goal = self.goal(previous.goal_id)
        if (
            previous.goal_contract_digest not in {None, goal.contract_digest}
            or previous.goal_contract_digest is None
            and previous.goal_digest != goal.digest
            or previous.scope != goal.request.scope
            or previous.checker != goal.checker
        ):
            raise ValueError("reobservation does not preserve the registered goal contract")
        candidate = await self._observe(goal)
        # Host mutation and concurrent evidence changes must not publish stale observations.
        if self.goal(goal.id).digest != goal.digest:
            raise Conflict("goal changed before reobservation")
        return await run_blocking(
            self.observations.renew,
            candidate,
            previous,
            cause_id(caller, goal.id),
            request_id,
            command,
            reason,
            new_attempt,
            self.reobservation_policy,
            goal.lifetime_seconds,
        )

    async def discover(self, *, max_candidates: int = 8, start: int = 0) -> Discovery:
        if not 1 <= max_candidates <= 32 or not 0 <= start < len(self._goals):
            raise ValueError("invalid discovery bound")
        found: list[Opportunity] = []
        expired: list[Opportunity] = []
        superseded: list[Opportunity] = []
        discovered = deduplicated = satisfied = 0
        # Each target has an indexed bounded dependency snapshot. No all-pairs scan.
        end = min(start + max_candidates, len(self._goals))
        for goal_id in tuple(self._goals)[start:end]:
            goal = self.goal(goal_id)
            started = time.perf_counter()
            observed_result = "interrupted"
            observed_id = None
            observed_kind = None
            try:
                candidate = await self._observe(goal)
                if candidate is None:
                    observed_result = "satisfied"
                    satisfied += 1
                    continue
                if self.goal(goal.id).digest != goal.digest:
                    raise Conflict("goal changed before observation")
                item, inserted, old = await run_blocking(
                    self.observations.publish,
                    candidate,
                    cause_id(self.identity.name, goal.id),
                    goal.lifetime_seconds,
                )
                observed_id = item.id
                observed_kind = item.work_kind
                if item.expires_at <= now():
                    expired.append(item)
                    observed_result = "expired"
                    continue
                if old:
                    superseded.append(item)
                    observed_result = "superseded"
                    continue
                observed_result = "discovered" if inserted else "deduplicated"
                discovered += int(inserted)
                deduplicated += int(not inserted)
                found.append(item)
            finally:
                event = Event(
                    schema_version="3",
                    work=WorkObservation(
                        receiver=self.identity.name,
                        scope=goal.request.scope,
                        policy_digest=self.registry.overlay.policy.digest,
                        goal_id=goal.id,
                        goal_digest=goal.digest,
                        opportunity_id=observed_id,
                        work_kind=observed_kind,
                        stage="discovery",
                        result=observed_result,
                    ),
                    issuer=self.identity.name,
                    subject=goal.request.subject,
                    action="recommendation",
                    task_id=goal.id,
                    attempt_id=uid(),
                    correlation_id=goal.id,
                    costs=(
                        Cost(
                            category="overhead",
                            status="measured",
                            unit="wall_seconds",
                            quantity=Decimal(str(round(time.perf_counter() - started, 9))),
                        ),
                        Cost(category="overhead", status="unavailable", unit="USD", quantity=None),
                    ),
                )
                await asyncio.shield(
                    run_blocking(self.registry.overlay.store.put, self.identity.sign(event))
                )
        return Discovery(
            opportunities=tuple(found),
            discovered=discovered,
            deduplicated=deduplicated,
            satisfied=satisfied,
            next_goal=end if end < len(self._goals) else None,
            expired=tuple(expired),
            superseded=tuple(superseded),
            next_action="reobserve" if expired or superseded else None,
        )

    def validate_proposal(
        self, envelope: dict[str, Any], caller: str, context: ExecutionContext
    ) -> Proposal:
        """Check authenticated input against host constraints, without executing it."""
        store = self.registry.overlay.store
        proposal = authenticate_proposal(envelope, caller, store.principals)
        return self._validate_proposal(proposal, caller, context)

    def _validate_proposal(
        self, proposal: Proposal, caller: str, context: ExecutionContext
    ) -> Proposal:
        """Only for records already authenticated by verify or Store resolution."""
        store = self.registry.overlay.store
        if context.caller != self.identity.name or context.purpose != "reuse":
            raise ValueError("proposal selection requires owner execution context")
        if proposal.goal_id not in self._goals:
            raise ProposalRejected("authorization", "proposal names an unregistered goal")
        goal = self.goal(proposal.goal_id)
        if caller not in {self.identity.name, *goal.peers}:
            raise ProposalRejected("authorization", "peer not authorized for this goal")
        if proposal.goal_digest != goal.digest or proposal.scope != goal.request.scope:
            raise ProposalRejected("scope", "proposal changes the registered goal or scope")
        if proposal.subject != goal.request.subject or self.identity.name not in proposal.receivers:
            raise ProposalRejected("scope", "proposal target or receiver mismatch")
        if proposal.expires_at <= now():
            raise ProposalRejected("expired", "proposal expired")
        if (
            proposal.opportunity.kind != "opportunity"
            or proposal.opportunity.issuer != self.identity.name
        ):
            raise ProposalRejected("reference", "proposal does not reference a local opportunity")
        page = store.record_page(
            RecordQuery(
                kinds=("opportunity",), issuer=self.identity.name, record_id=proposal.opportunity.id
            ),
            limit=1,
        )
        if not page.items:
            raise ProposalRejected("reference", "proposal references a missing opportunity")
        exact = store.reference("opportunity", self.identity.name, proposal.opportunity.id)
        if exact != proposal.opportunity:
            raise ProposalRejected("reference", "proposal changes the opportunity reference")
        opportunity = store.resolve_reference(proposal.opportunity)
        if not isinstance(opportunity, Opportunity) or (
            opportunity.issuer != self.identity.name
            or opportunity.goal_digest != goal.digest
            or opportunity.goal_contract_digest not in {None, goal.contract_digest}
            or opportunity.scope != goal.request.scope
            or opportunity.subject != goal.request.subject
            or opportunity.checker != goal.checker
            or opportunity.expires_at <= now()
            or opportunity.policy_digest != self.registry.overlay.policy.digest
            or not self.observations.is_current(opportunity.id)
        ):
            raise ProposalRejected("reference", "proposal refers to an inapplicable opportunity")
        if proposal.expires_at > opportunity.expires_at:
            raise ProposalRejected("expired", "proposal cannot extend its observation lifetime")
        for reference in opportunity.basis:
            basis = store.resolve_reference(reference)
            if isinstance(basis, Decision) and (
                basis.request != goal.request
                or basis.policy_digest != opportunity.policy_digest
                or basis.revisions != store.revisions(set(basis.revisions))
            ):
                raise ProposalRejected(
                    "reference", "opportunity observation changed; rediscovery required"
                )
        if proposal.builder not in goal.builders:
            raise ProposalRejected("authorization", "builder is not authorized for this goal")
        binding = self.registry.inspect(proposal.builder.id)
        if binding.issuer != proposal.builder.issuer or binding.digest != proposal.builder.digest:
            raise ProposalRejected("reference", "installed builder identity changed")
        try:
            self.registry.prepare(binding.id, binding.digest, proposal.arguments, context)
        except (InvalidArguments, SchemaError) as exc:
            raise ProposalRejected(
                "arguments", "proposal arguments violate the builder contract"
            ) from exc
        return proposal
