"""Isolated finite document comparison; raw negative results are retained."""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import importlib.metadata
import json
import os
import random
import re
import sys
import time
from decimal import Decimal
from pathlib import Path
from typing import Any

import httpx
from a2a.client import AgentCardResolutionError
from adaptive_documents import ENVIRONMENT, configure_application, write_json
from sqlalchemy import select
from sqlalchemy.engine import make_url

from collective_intelligence_overlay.accounting import metrics_page
from collective_intelligence_overlay.adapters.a2a import send
from collective_intelligence_overlay.bindings import fingerprint
from collective_intelligence_overlay.demo import initialize
from collective_intelligence_overlay.invocations import invocations
from collective_intelligence_overlay.queries import RecordCursor, RecordQuery
from collective_intelligence_overlay.storage import budgets, leases

ALLOWANCES = {
    "baseline": {"producer": Decimal(50), "receiver": Decimal(50), "verifier": Decimal(50)},
    "verification": {"producer": Decimal(50), "receiver": Decimal(50), "verifier": Decimal(14)},
}
TRAINING = "calibration vocabulary"
HELD_OUT = (
    "A separate evaluation document has seven words.",
    "one",
    "Unicode 文書\twith\nwhitespace",
)


def export_owner(config: Any, destination: Path) -> dict[str, Any]:
    """Export original signed records and page-local costs without private config."""
    _, overlay = config.runtime()
    store = overlay.store
    try:
        pages = []
        cursor = None
        for _ in range(128):
            page = metrics_page(store, cursor=cursor, limit=128)
            pages.append(page)
            if page["complete"]:
                break
            cursor = RecordCursor.model_validate(page["next_cursor"])
        else:
            raise ValueError("metric export exceeded declared page bound")
        signed = []
        for kinds in (
            ("capability", "evidence", "revocation", "event"),
            ("opportunity", "proposal"),
        ):
            cursor = None
            for _ in range(128):
                page = store.record_page(RecordQuery(kinds=kinds), cursor=cursor, limit=128)
                for item in page.items:
                    key = item.subject.key if item.kind == "capability" else item.id
                    signed.append(store.signed_record(store.reference(item.kind, item.issuer, key)))
                if page.next_cursor is None:
                    break
                cursor = page.next_cursor
            else:
                raise ValueError("record export exceeded declared page bound")
        with store.engine.connect() as conn:
            execution_states = [
                dict(row)
                for row in conn.execute(
                    select(
                        invocations.c.caller,
                        invocations.c.id,
                        invocations.c.lease_id,
                        invocations.c.state,
                        invocations.c.phase,
                        invocations.c.reservation_state,
                        invocations.c.release_reason,
                    )
                ).mappings()
            ]
            remaining = {row.unit: str(row.remaining) for row in conn.execute(select(budgets))}
            reserved = [
                {
                    "task": row.task_id,
                    "unit": row.unit,
                    "reservation": str(row.reservation),
                    "state": row.state,
                    "actual": str(row.actual) if row.actual is not None else None,
                }
                for row in conn.execute(select(leases))
            ]
        write_json(
            destination,
            {
                "owner": store.owner,
                "database_identity": make_url(config.database_url.get_secret_value()).database,
                "public_identities": {
                    key: value.model_dump(mode="json") for key, value in config.identities.items()
                },
                "invocations": execution_states,
                "metrics_pages": pages,
                "signed_records": signed,
                "remaining": remaining,
                "reservations": reserved,
            },
        )
        return {
            "report": destination.name,
            "remaining": remaining,
            "signed_record_count": len(signed),
        }
    finally:
        store.close()


async def run_arm(
    directory: Path, admin_url: str, opa: str, mode: str, scenario: str
) -> dict[str, Any]:
    if mode not in {"static-run", "adaptive-run"} or scenario not in ALLOWANCES:
        raise ValueError("unknown experiment assignment")
    if await asyncio.to_thread(directory.exists):
        raise FileExistsError("experiment arm directory already exists")
    started = time.perf_counter()
    report: dict[str, Any] = {
        "mode": mode,
        "scenario": scenario,
        "status": "incomplete",
        "calls": [],
        "business_results": [],
        "missing_costs": ["CPU_seconds", "tokens", "USD"],
        "allowance_is_measured_cost": False,
    }
    configs: dict[str, Any] = {}
    identities = {}
    processes = []
    logs = []
    stage = "initialize"

    async def call(owner: str, **data: Any) -> dict[str, Any]:
        if len(report["calls"]) >= 128:
            raise ValueError("external call bound exceeded")
        call_started = time.perf_counter()
        item = {"owner": owner, "operation": data["operation"], "status": "unknown"}
        report["calls"].append(item)
        try:
            value = await send(configs[owner], identities[owner], owner, data)
            item["status"] = "returned"
            return value
        finally:
            item["wall_seconds"] = time.perf_counter() - call_started

    async def sync(owner: str, source: str) -> None:
        if not (await call(owner, operation="sync", peer=source, page_size=4))["complete"]:
            raise ValueError("incomplete initial synchronization")

    try:
        async with asyncio.timeout(240):
            allowance = ALLOWANCES[scenario]
            report["initial_allowance"] = {owner: str(value) for owner, value in allowance.items()}
            initializing = asyncio.create_task(
                asyncio.to_thread(initialize, directory, admin_url, opa, work_allowances=allowance)
            )
            try:
                configs = await asyncio.shield(initializing)
            except asyncio.CancelledError:
                configs = await initializing
                raise
            for owner, original in configs.items():
                config = original.model_copy(
                    update={"execution_environment": ENVIRONMENT, "max_seconds": 300}
                )
                configs[owner] = config
                value = config.model_dump(mode="json")
                value["database_url"] = config.database_url.get_secret_value()
                write_json(config.private_key.parent / "config.json", value)
                identity, overlay = config.runtime()
                identities[owner] = identity
                overlay.store.close()
            configure_application(configs, TRAINING)
            stage = "startup"
            for owner, config in configs.items():
                log = (config.private_key.parent / "experiment.log").open("wb")
                logs.append(log)
                process = await asyncio.create_subprocess_exec(
                    sys.executable,
                    str(Path(__file__).with_name("adaptive_documents.py").resolve()),
                    "--config",
                    str(config.private_key.parent / "config.json"),
                    stdout=log,
                    stderr=log,
                )
                processes.append(process)
                async with asyncio.timeout(25):
                    while True:
                        if process.returncode is not None:
                            raise RuntimeError("peer exited during startup")
                        try:
                            await send(config, identities[owner], owner, {"operation": "metrics"})
                            break
                        except (httpx.HTTPError, ConnectionError, AgentCardResolutionError):
                            await asyncio.sleep(0.1)
            stage = "initial_checks"
            for provider, name, arguments in (
                ("producer", "words", {"text": "initial primitive check"}),
                ("receiver", "render", {"words": 7}),
                ("receiver", "remote-words", {"text": "remote primitive check"}),
            ):
                result = await call(
                    "verifier",
                    operation="verify",
                    attempt="initial-" + name,
                    provider=provider,
                    name=name,
                    arguments=arguments,
                )
                if result["evidence"]["verdict"] != "PASS":
                    raise ValueError("initial primitive check did not pass")
                if name == "words":
                    await sync("producer", "verifier")
                    await sync("receiver", "producer")
                    await sync("receiver", "verifier")
            await sync("receiver", "verifier")
            for target in ("verifier", "receiver"):
                checked = await call("producer", operation="certify-checker", target=target)
                report.setdefault("checker_calibration", []).append(checked)
                if checked.get("evidence", {}).get("verdict") != "PASS":
                    raise ValueError("checker calibration not PASS")
                if target == "verifier":
                    await sync("verifier", "producer")
                    await sync("receiver", "verifier")
                await sync("receiver", "producer")
            report["setup_wall_seconds"] = time.perf_counter() - started
            stage = "formation"
            run = await call("receiver", operation=mode, max_steps=8)
            report["run"] = run
            report["passed_formation_checks"] = len(
                {
                    item["evidence"]["binding_digest"]
                    for item in run["history"]
                    if item["kind"] == "verification"
                    and item.get("evidence")
                    and item["evidence"]["verdict"] == "PASS"
                }
            )
            stage = "business_evaluation"
            if run["reason"] == "goals_satisfied":
                target = await call("receiver", operation="describe", name="triage")
                from collective_intelligence_overlay.bindings import Binding

                binding = Binding.model_validate(target["binding"])
                for index, text in enumerate(HELD_OUT):
                    output = await call(
                        "receiver",
                        operation="invoke",
                        invocation_id=f"evaluation-{index}",
                        binding_id=binding.id,
                        binding_digest=binding.digest,
                        arguments={"text": text},
                    )
                    expected = {
                        "long": len(re.findall(r"\S+", text)) > len(re.findall(r"\S+", TRAINING)),
                        "threshold": len(re.findall(r"\S+", TRAINING)),
                    }
                    passed = output.get("state") == "completed" and output.get("result") == expected
                    report["business_results"].append(
                        {
                            "task": index,
                            "input": text,
                            "expected": expected,
                            "output": output,
                            "passed": passed,
                        }
                    )
            report["status"] = "finished" if run["reason"] == "goals_satisfied" else "censored"
    except Exception as exc:
        report.update(status="failed", failed_stage=stage, error_type=type(exc).__name__)
    finally:
        report["time_to_last_outcome_seconds"] = time.perf_counter() - started
        for process in processes:
            if process.returncode is None:
                process.terminate()
            try:
                await asyncio.wait_for(process.wait(), 10)
            except TimeoutError:
                process.kill()
                await process.wait()
        for log in logs:
            log.close()
        report["owners"] = {}
        for owner, config in configs.items():
            try:
                report["owners"][owner] = await asyncio.to_thread(
                    export_owner, config, directory / f"{owner}-observations.json"
                )
            except Exception as exc:
                report["owners"][owner] = {"export_error": type(exc).__name__}
                report["status"] = "incomplete_export"
        report["passed_business_tasks"] = sum(item["passed"] for item in report["business_results"])
        report["unreached_business_tasks"] = len(HELD_OUT) - len(report["business_results"])
        report["wall_including_export_seconds"] = time.perf_counter() - started
        if configs:
            write_json(directory / "result.json", report)
    return report


async def compare(directory: Path, admin_url: str, opa: str, seed: int = 0) -> dict[str, Any]:
    await asyncio.to_thread(directory.mkdir, parents=True, exist_ok=False)
    assignments = [
        (scenario, mode)
        for scenario in ("baseline", "verification")
        for mode in ("static-run", "adaptive-run")
    ]
    random.Random(seed).shuffle(assignments)
    protocol = {
        "version": "documents-comparison.v2",
        "initial_work_allowance": {
            scenario: {owner: str(value) for owner, value in amounts.items()}
            for scenario, amounts in ALLOWANCES.items()
        },
        "pilot_adjustment": "v1 verifier=10 stopped during calibration; v2 verifier=14 tests post-calibration checking scarcity; all v1 results retained",
        "sources": {
            name: hashlib.sha256(Path(__file__).with_name(name).read_bytes()).hexdigest()
            for name in (
                "evaluate_documents.py",
                "adaptive_documents.py",
                "document_application.py",
            )
        },
        "seed": seed,
        "assignments": assignments,
        "training": TRAINING,
        "held_out": HELD_OUT,
        "arm_timeout_seconds": 240,
        "step_bound": 8,
        "exclusions": "none; all failures and censoring retained",
        "versions": {
            name: importlib.metadata.version(name)
            for name in ("collective-intelligence-overlay", "agent-framework-core", "a2a-sdk")
        },
    }
    write_json(directory / "protocol.json", protocol)
    results = []
    for index, (scenario, mode) in enumerate(assignments):
        result = await run_arm(directory / f"arm-{index}", admin_url, opa, mode, scenario)
        results.append({"directory": f"arm-{index}", **result})
        write_json(
            directory / "results.json",
            {
                "protocol_digest": fingerprint(protocol),
                "arms": results,
                "limitations": [
                    "one deterministic run per condition; no statistical superiority claim",
                    "connection/environment scenario not yet implemented",
                    "wall times are inclusive observations, never summed across parent/child calls",
                ],
            },
        )
        print(
            json.dumps(
                {
                    "arm": index,
                    "scenario": scenario,
                    "mode": mode,
                    "status": result["status"],
                    "passed_business_tasks": result["passed_business_tasks"],
                }
            ),
            flush=True,
        )
    return {"protocol": protocol, "arms": results}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--directory", type=Path, required=True)
    parser.add_argument("--opa", required=True)
    parser.add_argument("--seed", type=int, default=0)
    args = parser.parse_args()
    url = os.environ.get("CIO_TEST_DATABASE_URL")
    if not url:
        parser.error("CIO_TEST_DATABASE_URL must name a dedicated PostgreSQL admin database")
    asyncio.run(compare(args.directory.resolve(), url, str(Path(args.opa).resolve()), args.seed))


if __name__ == "__main__":
    main()
